/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciogallina;

/**
 *
 * @author DOCENTE
 */
public class Gallina {
    private String nombre;
    private double peso;
    private int cantidadHuevos;

    public Gallina(String nombre, double peso, int cantidadHuevos) {
        this.nombre = nombre;
        this.peso = peso;
        this.cantidadHuevos = cantidadHuevos;
    }

    public Gallina() {

    }

    public String getNombre() {
        return nombre;
    }

    public double getPeso() {
        return peso;
    }

    public int getCantidadHuevos() {
        return cantidadHuevos;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void setCantidadHuevos(int cantidadHuevos) {
        this.cantidadHuevos = cantidadHuevos;
    }
    
    public String ficha()
    {
        return "---------------------------------------------\n" +
        "       Gallina: "+nombre+"\n" +
        "---------------------------------------------\n" +
        "Peso: "+peso+" kg.\n" +
        "Total Huevos: "+cantidadHuevos+" huevos";
    }
    
    public void comer(double cantidadComida)
    {
        peso=peso+0.08*cantidadComida;
        cantidadHuevos=(int)(cantidadHuevos*1.2);
    }
    
    public int sacarHuevo()
    {
        int saca;
        saca=(int)(cantidadHuevos*0.7);
        cantidadHuevos=(int)(cantidadHuevos*0.3);
        return saca;
    }
     
}
