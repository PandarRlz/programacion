/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciogallina;

import java.util.Scanner;

public class EjercicioGallina {
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
//        Gallina galli1,galli2;
//        String nom;
//        double peso,nuevoPeso;
//        int cantdad;
//        
//        galli1=new Gallina();
//        System.out.println("Ingrese los datos de la gallina 2");
//        System.out.print("Nombre: ");
//        nom=teclado.nextLine();
//        System.out.print("Peso: ");
//        peso=teclado.nextDouble();
//        System.out.print("Cantidad de huevos: ");
//        cantdad=teclado.nextInt();
//        galli2=new Gallina(nom, peso, cantdad);
//        
//        System.out.println("La gallina 1 se llama "+galli1.getNombre());
//        System.out.println("La gallina 2 se llama "+galli2.getNombre());
//        System.out.print("Ingrese el nuevo peso de la gallina 1: ");
//        nuevoPeso=teclado.nextDouble();
//        galli1.setPeso(nuevoPeso);
//        System.out.println("La gallina 1 pesa: "+galli1.getPeso());
//        System.out.println("Gallinita 2");
//        System.out.println(galli2.ficha());
//        System.out.println("Gallinita 1");
//        System.out.println(galli1.ficha());
    
    int op,cantidad,nuevaCantidad;
    Gallina turuleka=null;
    String nombre;
    double peso,comida;
    
    
    do
    {
        System.out.println("""
                           Gallinas Felices
                           *************
                           1. Crear Gallina
                           2. Mostrar informaci\u00f3n (debe utilizar el m\u00e9todo ficha)
                           3. Comer
                           4. Modificar la cantidad total de huevos (validar que no sea la misma que ten\u00eda)
                           5. Sacar huevos
                           6. Salir
                           Elija Opci\u00f3n:
                           Profesora: Sonia Arriagada G. Lenguaje Java
                           1""");
        op=teclado.nextInt();
        switch(op)
        {
            case 1:
                System.out.println("Ingrese datos de la gallina: ");
                System.out.println("Nombre: ");
                teclado.nextLine();
                nombre=teclado.nextLine();
                System.out.println("Peso: ");
                peso=teclado.nextDouble();
                System.out.println("Cantidad de huevos que puso: ");
                cantidad=teclado.nextInt();
                turuleka=new Gallina(nombre, peso, cantidad);
                System.out.println("Gallinita Creada ");
                
                break;
                
            case 2:
                if(turuleka!=null)
             
                {
                System.out.println(turuleka.ficha());
                }
                else
                    System.out.println("Debe crear a la gallina");
                break;
                
            case 3:
                if(turuleka!=null)
             
                {
                System.out.println("Ingrese La cantidad de Comida: ");
                comida=teclado.nextDouble();
                turuleka.comer(comida);
                System.out.println("La Gallinita Comio. ");
                
                }
                else
                    System.out.println("Debe crear a la gallina");
                break;
                
            case 4:
                if(turuleka!=null)
             
                {
                    do
                    {
                        //Aca se valida la cantiadadHuevos para agregarle una nuevaCantidad que no debe ser igual a la que tenia, Entonces se hace un do while para validar
                        System.out.println("Ingrese la nueva Cantidad de Huevos: ");
                        nuevaCantidad=teclado.nextInt();
                    }while(nuevaCantidad==turuleka.getCantidadHuevos());
                    turuleka.setCantidadHuevos(nuevaCantidad);
                    
                }
                else
                    System.out.println("Debe crear a la gallina");
                break;
                
            case 5:
                if(turuleka!=null)
             
                {
                System.out.println("Se sacaron "+turuleka.sacarHuevo()+" Huevos");
                }
                else
                    System.out.println("Debe crear a la gallina");
                break;
        }
        
    }while(op!=6);
    
    }
    
}
