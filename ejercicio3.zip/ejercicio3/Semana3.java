/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package semana3;

import java.util.Scanner;

public class Semana3 {

    public static void main(String[] args) {
        int op;
        Scanner teclado=new Scanner(System.in);
        
        Alumno alu=null;
        String nom,rut;
        double n1,n2,n3,nueva,ne;
        
        do
        {
            System.out.println("""
                               1.\tCrear alumno
                               2.\tMostrar toda la informaci\u00f3n del alumno 
                               3.\tModificar la nota de la prueba 2 (validar que no sea la misma que tenia), mostrando la nueva nota
                               4.\tNota final y si aprob\u00f3 o no la asignatura
                               5.\tSalir
                               \t\tElija opci\u00f3n:""");
            op=teclado.nextInt();
            switch(op)
            {
                case 1:
                    System.out.println("Ingrese los datos del alummno: ");
                    System.out.print("Nombre: ");
                    teclado.nextLine();
                    nom=teclado.nextLine();
                    System.out.print("Rut: ");
                    rut=teclado.nextLine();
                    System.out.print("Nota Prueba 1: ");
                    n1=teclado.nextDouble();
                    System.out.print("Nota Prueba 2: ");
                    n2=teclado.nextDouble();
                    System.out.print("Nota Prueba 3: ");
                    n3=teclado.nextDouble();
                    alu=new Alumno(rut, nom, n1, n2, n3);
                    System.out.println("Alumno Creado con Exito!");
                    break;
                    
                case 2:
                    
                    if(alu!=null)//esto se hace para validar
                    {
                        System.out.println("\n\tDatos del alumno");
                        System.out.println("Nombre: "+alu.getNombre());
                        System.out.println("Nota Prueba 1: "+alu.getNotaPrueba1());
                        System.out.println("Nota Prueba 2: "+alu.getNotaPrueba2());
                        System.out.println("Nota Prueba 3: "+alu.getNotaPrueba3());
                        
                    }
                    else
                        System.out.println("Debe crear al alumno");
                    break;
                    
                case 3:
                    if(alu!=null)
                    {
                        System.out.println("Modificacion de notas ");
                        do   //ACA ESTAMOS VALIDANDO QUE NO SEA LA MISMA NOTA
                        {
                        System.out.print("Ingrese la Nueva nota 2;");
                        nueva=teclado.nextDouble();
                        }while(nueva==alu.getNotaPrueba2());
                        
                        alu.setNotaPrueba2(nueva);
                        System.out.println("La nota Prueba 2 quedo En "+alu.getNotaPrueba2());
                        
                    }
                    
                    break;
                    
                case 4:
                    if(alu!=null)
                    {
                        System.out.println("\n\tIngrese Nota del Examen: ");
                        ne = teclado.nextDouble();
                        System.out.println("Nota final: "+alu.notaFinal(ne));
                        System.out.println(alu.situacion(ne));
                    }
                    else
                        System.out.println("Debe crear alumno");
                    break;
                    
            }
        }while(op!=5);
    }
    
}
