/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioclinica;

import java.util.Scanner;

/**
 *
 * @author PC07
 */
public class EjercicioClinica {


    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        
    }
    
}
