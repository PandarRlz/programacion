/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioclinica;

/**
 *
 * @author PC07
 */
public class Paciente {
    private String nombre,genero;
    private Double pesoKg,estaturaCm;

    public Paciente(String nombre, String genero, Double pesoKg, Double estaturaCm) {
        this.nombre = nombre;
        this.genero = genero;
        this.pesoKg = pesoKg;
        this.estaturaCm = estaturaCm;
    }

    public Paciente() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Double getPesoKg() {
        return pesoKg;
    }

    public void setPesoKg(Double pesoKg) {
        this.pesoKg = pesoKg;
    }

    public Double getEstaturaCm() {
        return estaturaCm;
    }

    public void setEstaturaCm(Double estaturaCm) {
        this.estaturaCm = estaturaCm;
    }
    
    public double imc()
    {
        return pesoKg/((estaturaCm/100)*(estaturaCm/100));   
    }
    
    public String estadoPaciente()
    {
        if(imc()>=18.5 && imc()<=25)
            return "Normal";
        if(imc()>=25 && imc()<30)
            return "Sobre Peso";
        if(imc()>=30)
            return "Obeso ";
        return "Delgadez";
        
    }
    
    
    
}
