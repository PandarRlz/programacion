/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioclinica;

/**
 *
 * @author PC07
 */
public class Doctor {
    private String nombre;
    private String especialidad;
    private Paciente paciente;
    private int valorConsulta;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    public int getValorConsulta() {
        return valorConsulta;
    }

    public void setValorConsulta(int valorConsulta) {
        this.valorConsulta = valorConsulta;
    }

    public Doctor() {
    }

    public Doctor(String nombre, String especialidad, Paciente paciente, int valorConsulta) {
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.paciente = paciente;
        this.valorConsulta = valorConsulta;
    }
    
    
    
}
